import { Component, OnInit } from '@angular/core';
import { Subscription, timer } from 'rxjs';
import { Books } from 'src/app/books';
import { Genres } from 'src/app/genres';
import { BooksService } from 'src/app/services/books.service';
import { GenresService } from 'src/app/services/genres.service';
import { switchMap } from 'rxjs/operators';
import { interval } from 'rxjs';


@Component({
  selector: 'app-bookslist',
  templateUrl: './bookslist.component.html',
  styleUrls: ['./bookslist.component.css']
})
export class BookslistComponent implements OnInit {

  books: any[];
  genres: any[];
  authors: any[];
  inEdit: boolean = false;
  book: Books = new Books();
  selectedGenre?: number = null;
  tableMode: boolean = true;
  genre: Genres = new Genres();
  subscription: Subscription;
  statusText: string;

  constructor(private booksService: BooksService, private genresService: GenresService) { }


  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  async ngOnInit() {
    interval(2000).subscribe(x => {debugger
      this.syncData()
    });
    this.loadData();
  }

  syncData(){
    var keys = Object.keys(localStorage);
    keys.forEach(key => {
      let t:number = +key;
      var data = JSON.parse(localStorage.getItem(key));
      if(data === 'delete'){
        this.delete(this.books[t]);
      }
      else if(this.books.length - 1 >= t){
        this.booksService.updateBook(data).subscribe(data => this.loadData());
      }
      else{
        this.booksService.addBook(data).subscribe(data1 => this.books.push(data1));
      }
    });
  }

  loadData() {
    this.loadAllBooks();
    this.loadGenres();
  }

  async loadAllBooks() {
    this.booksService.getAll().subscribe((data: Books[]) => this.books = data);
  }


  async loadGenres() {
    this.genresService.getAll().subscribe((data: Genres[]) => this.genres = data);
  }

  async loadByGenres(id: number) {
    this.booksService.getbygenre(id).subscribe((data: Books[]) => this.books = data);
  }

  async save() {
    if (this.book.id == null) {
      this.booksService.addBook(this.book).subscribe(data => {
        this.books.push(data);
        localStorage.setItem((this.books[this.books.length - 1].id + 1).toString(), JSON.stringify(this.book))
      });
    }
    else {
      this.booksService.updateBook(this.book).subscribe(data => {
        this.loadData();
        localStorage.setItem(this.book.id.toString(), JSON.stringify(this.book));
      });
    }
    if (this.genre.id == null) {
      this.genresService.addGenre(this.genre).subscribe(data => {
        this.genres.push(data);
        localStorage.setItem((this.genres[this.genres.length - 1].id + 1).toString(), JSON.stringify(this.genre))
      });
    }
    else {
      this.genresService.updateGenre(this.genre).subscribe(data => {
        localStorage.setItem(this.genre.id.toString(), JSON.stringify(this.genre));
        this.loadData();
      });
    }
    this.cancel();
  }
  cancel() {
    this.inEdit = false;
    this.book = new Books();
    this.genre = new Genres();
    this.tableMode = true;
  }
  editBook(b: Books) {
    this.inEdit = true;
    this.book = b;
  }
  update() {
    if (this.selectedGenre == null) {
      this.loadData();
    }
    else {
      this.loadByGenres(this.selectedGenre);
    }
  }
  delete(b: Books) {
    localStorage.setItem(b.id.toString(), JSON.stringify('delete'));
    this.booksService.delete(b.id).subscribe(data => this.loadData());
  }
  deleteGenre() {
    this.genresService.delete(this.selectedGenre).subscribe(data => this.loadData());
    this.cancel();
  }
  addBook() {
    this.cancel();
    this.tableMode = false;
  }
  addGenre() {
    this.cancel();
  }
}
