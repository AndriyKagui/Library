import { Component, OnInit } from '@angular/core';
import { Books } from 'src/app/books';
import { Genres } from 'src/app/genres';
import { BooksService } from 'src/app/services/books.service';
import { GenresService } from 'src/app/services/genres.service';


@Component({
  selector: 'app-bookslist',
  templateUrl: './bookslist.component.html',
  styleUrls: ['./bookslist.component.css']
})
export class BookslistComponent implements OnInit {

  books: any[];
  genres: any[];
  authors: any[];
  inEdit: boolean = false;
  book: Books = new Books();
  selectedGenre?: number = null;
  tableMode: boolean = true;
  genre: Genres = new Genres();

  constructor(private booksService: BooksService, private genresService: GenresService) { }

  async ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.loadAllBooks();
    this.loadGenres();
  }

  async loadAllBooks() {
    this.booksService.getAll().subscribe((data: Books[]) => this.books = data);
  }


  async loadGenres() {
    this.genresService.getAll().subscribe((data: Genres[]) => this.genres = data);
  }

  async loadByGenres(id: number) {
    this.booksService.getbygenre(id).subscribe((data: Books[]) => this.books = data);
  }

  async save() {
    if(this.book.id == null){
    this.booksService.addBook(this.book).subscribe(data => this.books.push(data));
    }
    else{
      this.booksService.updateBook(this.book).subscribe(data => this.loadData());
    }
    if(this.genre.id == null){
      this.genresService.addGenre(this.genre).subscribe(data => this.genres.push(data));
    }
    else{
      this.genresService.updateGenre(this.genre).subscribe(data => this.loadData());
    }
    this.cancel();
  }
  cancel() {
    this.inEdit = false;
    this.book = new Books();
    this.genre = new Genres();
    this.tableMode = true;
  }
  editBook(b: Books) {
    this.inEdit = true;
    this.book = b;
  }
  update() {
    if (this.selectedGenre == null) {
      this.loadData();
    }
    else {
      this.loadByGenres(this.selectedGenre);
    }
  }
  delete(b: Books) {
    this.booksService.delete(b.id).subscribe(data => this.loadData());
  }
  deleteGenre(){
    this.genresService.delete(this.selectedGenre).subscribe(data => this.loadData());
    this.cancel();
  }
  addBook() {
    this.cancel();
    this.tableMode = false;
  }
  addGenre(){
    this.cancel();
  }
}
