export class Genres{
    constructor(
        public id?:number,
        public genre?:string
    ){}
}