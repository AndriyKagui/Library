import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Books } from '../books';

@Injectable({
  providedIn: 'root'
})
export class BooksService {

  constructor(private http:HttpClient) {}
  private readonly url = 'http://localhost:56807/api/';

    getAll(){
        return this.http.get(this.url + 'books');
    }

    get(id:number){
        return this.http.get(this.url + 'books/' + id);
    }

    getbygenre(id:number){
      return this.http.get(this.url + 'books/genre/' + id);
    }

    addBook(book:Books){
      return this.http.post(this.url + 'books', book);
    }

    updateBook(book:Books){
      return this.http.put(this.url + 'books', book);
    }

    delete(id: number){
      return this.http.delete(this.url + 'books/' + id);
    }

    getGenres(){
      return this.http.get(this.url + 'genres');
    }

    getAuthors(){
      return this.http.get(this.url + 'authors')
    }
}
