import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Genres } from '../genres';

@Injectable({
  providedIn: 'root'
})
export class GenresService {

  constructor(private http: HttpClient) { }
  private readonly url = 'http://localhost:56807/api/';

  getAll() {
    return this.http.get(this.url + 'genres');
  }

  get(id: number) {
    return this.http.get(this.url + 'genres/' + id);
  }

  addGenre(genre: Genres) {
    return this.http.post(this.url + 'genres/', genre);
  }

  updateGenre(genre: Genres) {
    return this.http.put(this.url + 'genres/', genre);
  }

  delete(id: number) {
    return this.http.delete(this.url + 'genres/' + id);
  }
}
