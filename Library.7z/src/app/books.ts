import { Genres } from './genres';

export class Books{
    constructor(
        public id?:number,
        public bookName?:string,
        public genreId?:number,
        public author?:string,
        public genre?:Genres
    ){}
}