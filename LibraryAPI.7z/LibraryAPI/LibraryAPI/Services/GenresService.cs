﻿using LibraryAPI.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LibraryAPI.Services
{
    public class GenresService : IRepository<Genres>
    {
        private librarydbContext db;

        public GenresService(librarydbContext db)
        {
            this.db = db;
        }
        public void Add(Genres entity)
        {
            db.Genres.Add(entity);
            db.SaveChanges();
        }

        public void Delete(int id)
        {
            Genres genre = Get(id);
            if (genre != null)
            {
                db.Genres.Remove(genre);
            }
            db.SaveChanges();
        }

        public Genres Get(int id)
        {
            Genres genre = db.Genres.FirstOrDefault(a => a.Id == id);
            return genre;
        }

        public IEnumerable<Genres> GetAll()
        {
            return db.Genres;
        }

        public void Update(Genres dbEntity)
        {
            Genres genre = Get(dbEntity.Id);
            if (genre != null)
            {
                genre.Genre = dbEntity.Genre;

                db.Genres.Update(genre);
                db.SaveChanges();
            }
        }
    }
}
