﻿using LibraryAPI.Repository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Threading.Tasks;

namespace LibraryAPI.Services
{
    public class BooksService : IRepository<Books>
    {
        private librarydbContext db;

        public BooksService(librarydbContext db)
        {
            this.db = db;
        }

        public void Add(Books entity)
        {
            if (entity.GenreId == null)
            {
                entity.GenreId = 1;
            }
            db.Books.Add(entity);
            db.SaveChanges();
        }

        public void Delete(int id)
        {
            Books book = Get(id);
            if(book != null)
            {
                db.Books.Remove(book);
            }
            db.SaveChanges();
        }

        public Books Get(int id)
        {
            Books book = db.Books.Include(g => g.Genre).FirstOrDefault(b => b.Id == id);
            return book;
        }

        public IEnumerable<Books> GetAll()
        {
            return db.Books.Include(g => g.Genre);
        }

        public void Update(Books dbEntity)
        {
            Books currBook = Get(dbEntity.Id);
            if(currBook != null)
            {
                currBook.BookName = dbEntity.BookName;
                currBook.Author = dbEntity.Author;
                currBook.GenreId = dbEntity.GenreId;

                db.Books.Update(currBook);
                db.SaveChanges();
            }
        }
    }
}
